package com.ecommerce.tests;

public class Calculator
{
    public int add(int a, int b) {
        return a + b;
    }
}
