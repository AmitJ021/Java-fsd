package Practice;

class MyClass {

    private int privateData = 10;

    public void printPrivateData() {
        System.out.println("Private data: " + privateData);
    }

    protected void modifyPrivateData(int newData) {
        privateData = newData;
    }
}

public class P02 {

    public static void main(String[] args) {
        MyClass obj = new MyClass();

        obj.printPrivateData();


        obj.modifyPrivateData(20);
        obj.printPrivateData(); 
    }
}
