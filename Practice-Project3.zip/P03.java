package Practice;

public class P03 {

    // Simple method to calculate square (call by value)
    public static int calculateSquare(int side) 
    {
        System.out.println("Inside calculateSquare(int): side = " + side);
        return side * side;
    }

    // Overloaded method to calculate area of a rectangle (call by value)
    public static double calculateArea(double length, double width) 
    {
        System.out.println("Inside calculateArea(double, double): length = " + length + ", width = " + width);
        return length * width;
    }

    // Main method to test and call other methods
    public static void main(String[] args) {

        // Verify method implementation (comments explain functionality)

        // Call by value - original variable remains unchanged
        int num = 5;
        int square = calculateSquare(num);
        System.out.println("Original num: " + num + ", Square: " + square);

        // Call overloaded method (different parameters)
        double rectLength = 4.5;
        double rectWidth = 2.0;
        double area = calculateArea(rectLength, rectWidth);
        System.out.println("Area of rectangle: " + area);
    }
}

