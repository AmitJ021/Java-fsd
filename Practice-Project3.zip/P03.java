package Practice;

public class P03 {

    public static int calculateSquare(int side) 
    {
        System.out.println("Inside calculateSquare(int): side = " + side);
        return side * side;
    }

    public static double calculateArea(double length, double width) 
    {
        System.out.println("Inside calculateArea(double, double): length = " + length + ", width = " + width);
        return length * width;
    }

    public static void main(String[] args) {

        
        int num = 5;
        int square = calculateSquare(num);
        System.out.println("Original num: " + num + ", Square: " + square);

        double rectLength = 4.5;
        double rectWidth = 2.0;
        double area = calculateArea(rectLength, rectWidth);
        System.out.println("Area of rectangle: " + area);
    }
}

