package Practice;

class Person {

    // Instance variables (accessible within the class)
    private String name;
    private int age;

    // Default constructor (no arguments)
    public Person() {
        System.out.println("Default constructor called.");
        name = "Unknown";
        age = 0;
    }

    // Parameterized constructor (takes name and age as arguments)
    public Person(String name, int age) {
        System.out.println("Parameterized constructor called with name: " + name + ", age: " + age);
        this.name = name; // Assign values to instance variables
        this.age = age;
    }

    // Method to display person's information
    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

public class P04 {

    public static void main(String[] args) {

        // Create objects using different constructors
        Person person1 = new Person(); // Calls default constructor
        Person person2 = new Person("Alice", 30); // Calls parameterized constructor

        // Verify object initialization by calling displayInfo
        person1.displayInfo();
        person2.displayInfo();
    }
}
