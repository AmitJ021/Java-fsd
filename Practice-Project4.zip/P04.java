package Practice;

class Person {

    private String name;
    private int age;

    public Person() {
        System.out.println("Default constructor called.");
        name = "Unknown";
        age = 0;
    }

    public Person(String name, int age) {
        System.out.println("Parameterized constructor called with name: " + name + ", age: " + age);
        this.name = name; 
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

public class P04 {

    public static void main(String[] args) {

        Person person1 = new Person(); 
        Person person2 = new Person("Alice", 30); 

        person1.displayInfo();
        person2.displayInfo();
    }
}
