package Practice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class P05 {

    public static void main(String[] args) {

        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        System.out.println("Array:"+names);
        
        System.out.println("\n");
	    System.out.println("Vector");
	    Vector<Integer> vec = new Vector();
	    vec.addElement(15); 
	    vec.addElement(30); 
	    System.out.println(vec);

        List<String> cities = new LinkedList<>();
        cities.add("London");
        cities.add("Paris");
        cities.add(0, "New York"); 
        System.out.println("\n");
        System.out.println("LinkedList(cities):"+cities);

        Set<String> fruits = new HashSet<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");
        fruits.add("Apple"); 
        System.out.println("\n");
        System.out.println("HashSet(fruits):"+fruits);

        Set<String> colors = new LinkedHashSet<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Red"); 
        System.out.println("\n");
        System.out.println("LinkedHashSet (colors):"+colors);
  
    }
}
