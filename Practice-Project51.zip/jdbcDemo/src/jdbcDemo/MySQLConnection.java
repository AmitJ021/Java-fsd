package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLConnection 
{
	public static void main(String arg[])
	{
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/loginuser", "root", "Amit@42685");

			
			if(connection!=null)
			{
				System.out.println("Connected to database successfully");
			}
		}
		catch (Exception exception) {
			System.out.println("Not connected to database");
		}
	}
	}