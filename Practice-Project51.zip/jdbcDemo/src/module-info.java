/**
 * 
 */
/**
 * 
 */
module jdbcDemo {
	requires java.sql;
}