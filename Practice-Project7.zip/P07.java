package Practice;

public class P07 
{

	 private String message = "Outer class message";

	    public static class StaticNestedClass 
	    {
	        public static void printMessage() 
	        {
	            P07 outer = new P07(); 
	            System.out.println("Static nested class: " + outer.message);  
	        }
	    }

    public class InnerClass 
    {
        public void printMessage() 
        {
            System.out.println("Inner class: " + message);
        }
    }

    public void printWithAnonymous() 
    {
        new Runnable() 
        {
            @Override
            public void run() 
            {
                System.out.println("Anonymous inner class: " + message);
            }
        }.run();
    }

    public static void main(String[] args) {

        StaticNestedClass.printMessage();

        P07 outer = new P07();
        InnerClass inner = outer.new InnerClass();
        inner.printMessage();

        outer.printWithAnonymous();
    }
}
