package Practice;

public class P08 {

    public static void main(String[] args) {

        String originalString = "Original string";

        // String Methods
        System.out.println("** String Methods **");
        System.out.println("Length: " + originalString.length());
        System.out.println("SubString:"+originalString.substring(2));
        
        String string2="Origianal string";
        System.out.println(originalString.compareTo(string2));
        
        System.out.println("Character at index 5: " + originalString.charAt(5)); // 'i'
        System.out.println("Contains 'original': " + originalString.contains("original")); // true
        System.out.println("Uppercase: " + originalString.toUpperCase());
        System.out.println("Uppercase: " + originalString.toLowerCase());
        
        String s4="";
		System.out.println(s4.isEmpty());

		String s6="Heldo";
		String replace=s6.replace('d', 'l');
		System.out.println(replace);
		System.out.println(s6);
        System.out.println("Trimmed: " + originalString.trim()); // removes leading/trailing spaces

        // Conversion to StringBuilder
        System.out.println("\n** String to StringBuilder Conversion**");
        StringBuilder stringBuilder = new StringBuilder(originalString);
        System.out.println("StringBuilder: " + stringBuilder);

        // StringBuilder Methods (mutable)
        stringBuilder.append(" - appended content");
        System.out.println("StringBuilder after append: " + stringBuilder);
        stringBuilder.insert(10, " (modified) "); // insert at index 10
        System.out.println("StringBuilder after insert: " + stringBuilder);

        // Conversion to StringBuffer (similar to StringBuilder)
        System.out.println("\n** String to StringBuffer Conversion**");
        StringBuffer stringBuffer = new StringBuffer(originalString);
        System.out.println("StringBuffer: " + stringBuffer);

        // StringBuffer Methods (mutable)
        stringBuffer.reverse();
        System.out.println("StringBuffer after reverse: " + stringBuffer);

        // Original String remains unchanged (immutable)
        System.out.println("\n** Original String **");
        System.out.println(originalString);
    }
}
