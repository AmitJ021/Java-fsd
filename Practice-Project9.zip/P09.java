package Practice;

public class P09 {

    public static void main(String[] args) {

        int numbers[] = {2,4,1,5,6,8};

        System.out.println("\nSingle-dimensional array:");
        for (int number : numbers) {
            System.out.println(number);
        }

        int numbers2[] []= {
        		{2,4,6,8},
        		{10,12,14,16},
        		{18,20,22,24}};
        
        System.out.println("\nMulti-dimensional array (2D):");
        System.out.println("Printing 2D array:");
        for (int i = 0; i < numbers2.length;i++)
        {
            for (int j = 0; j < numbers2[i].length; j++) 
            {
                System.out.print(numbers2[i][j]+ " ");
            }
            System.out.println(); 
        }
        System.out.println("\nLength of row 1: " + numbers2[0].length);
    }
}
