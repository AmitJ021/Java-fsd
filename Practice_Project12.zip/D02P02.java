package Practice;

public class D02P02 {

	  private static final Object LOCK = new Object();

	  public static void main(String[] args) throws InterruptedException {
	    Runnable notifier = () -> {
	      synchronized (LOCK) {
	        System.out.println("Thread '" + Thread.currentThread().getName() + "' notifying object '" + LOCK + "'");
	        LOCK.notify(); 
	      }
	    };

	    new Thread(notifier).start();

	    synchronized (LOCK) {
	      System.out.println("Thread '" + Thread.currentThread().getName() + "' is waiting on object '" + LOCK + "'");
	      LOCK.wait(1000); 
	      System.out.println("Object '" + LOCK + "' is woken after waiting for 1 second");
	    }
	  }
	}
