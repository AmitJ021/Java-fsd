package Practice;

public class D02P04 
{

	  public static void main(String[] args) 
	  {
	    int[] numbers = {1, 2, 3};

	    try {
	      System.out.println(numbers[5]); 
	    } 
	    catch (IndexOutOfBoundsException e) 
	    {
	      System.out.println("Exception: Array index out of bounds!");
	      System.out.println("Error message: " + e.getMessage());
	    } 
	    finally 
	    {
	      System.out.println("This block always executes, regardless of exceptions.");
	    }

	    System.out.println("Program continues after try-catch block.");
	  }
}
