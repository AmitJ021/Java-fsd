package Practice;

public class FinallyBlockDemo {
    public static void main(String[] args) {
        int dividend = 45;
        int divisor = 0;
        int result = 0;

        try {
            result = dividend / divisor;
        } catch (ArithmeticException ex) {
            System.out.println("\n\tError: " + ex.getMessage());
        } finally {
            System.out.println("\n\tThe result is: " + result);
        }
    }
}
