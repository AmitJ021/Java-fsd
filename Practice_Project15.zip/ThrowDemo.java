package Practice;

public class ThrowDemo {
    public static void main(String[] args) {
        int dividend = 45;
        int divisor = 0;
        int result;

        try {
            if (divisor == 0)
                throw new ArithmeticException("Can't divide by zero.");
            else {
                result = dividend / divisor;
                System.out.println("The result is: " + result);
            }
        } catch (ArithmeticException ex) {
            System.out.println("Error: " + ex.getMessage());
        }

        System.out.println("End of program.");
    }
}
