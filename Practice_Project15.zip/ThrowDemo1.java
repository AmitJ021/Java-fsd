package Practice;

public class ThrowDemo1 {
    void division() throws ArithmeticException {
        int dividend = 45;
        int divisor = 0;
        int result;

        result = dividend / divisor;
        System.out.println("The result is: " + result);
    }

    public static void main(String[] args) {
        ThrowDemo1 T = new ThrowDemo1();
        try {
            T.division();
        } catch (ArithmeticException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        System.out.println("End of program.");
    }
}

