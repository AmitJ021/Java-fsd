package Practice;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileLineReader 
{   

    public static List<String> readLinesFromFile(String filePath) throws IOException 
    {  
        
    	try 
    	{
            return Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
        } 
    	catch (IOException e) 
    	{
            throw e;  
        }
    }

    public static void main(String[] args) throws IOException 
    {
        List<String> lines = readLinesFromFile("C://Users//Pep Guardiola//Desktop//Phase 1//File2.txt");  

        for (String line : lines) 
        {
            System.out.println(line);
        }
    }
}
