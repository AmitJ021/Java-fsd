package Practice;

class Book 
{

   private String title;
   private String author;
   private int yearPublished;
   private int pages;

   public Book(String title, String author, int yearPublished, int pages) 
   {
       this.title = title;
       this.author = author;
       this.yearPublished = yearPublished;
       this.pages = pages;
   }

   public String getTitle() 
   {
       return title;
   }

   public void setTitle(String title) 
   {
       this.title = title;
   }

   public String getAuthor() 
   {
       return author;
   }

   public void setAuthor(String author) 
   {
       this.author = author;
   }

   public int getYearPublished() 
   {
       return yearPublished;
   }

   public void setYearPublished(int yearPublished) 
   {
       this.yearPublished = yearPublished;
   }

   public int getPages() 
   {
       return pages;
   }

   public void setPages(int pages)
   {
       this.pages = pages;
   }

   @Override
   public String toString() 
   {
       return "Book [title=" + title + ", author=" + author + ", yearPublished=" + yearPublished + ", pages=" + pages + "]";
   }
}

public class ClassObjMain 
{

   public static void main(String[] args) 
   {

       Book book1 = new Book("The Lord of the Rings", "J.R.R. Tolkien", 1954, 1136);

       System.out.println("Book details (initial):");
       System.out.println(book1.toString());

       book1.setTitle("Pride and Prejudice");
       book1.setAuthor("Jane Austen");
       book1.setYearPublished(1813);
       book1.setPages(224);

       System.out.println("\nBook details (modified):");
       System.out.println(book1.toString());

   }
}
