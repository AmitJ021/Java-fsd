package Practice;

 class BankAccount 
 {

	  private String accountNumber; 
	  private double balance;        

	  public BankAccount(String accountNumber, double initialBalance) 
	  {
	    this.accountNumber = accountNumber;
	    
	    if (initialBalance < 0) 
	    {
	      throw new IllegalArgumentException("Initial balance cannot be negative.");
	    }
	    this.balance = initialBalance;
	  }

	  public String getAccountNumber() 
	  {
	    return accountNumber;
	  }

	  public void deposit(double amount) 
	  {
	    if (amount <= 0) {
	      throw new IllegalArgumentException("Deposit amount must be positive.");
	    }
	    balance += amount;
	  }

	  public void withdraw(double amount) {
	    if (amount <= 0) {
	      throw  new IllegalArgumentException("Withdrawal amount must be positive.");
	    }
	    if (amount > balance) {
	      throw new InsufficientFundsException("Insufficient funds for withdrawal."); // Custom exception
	    }
	    balance -= amount;
	  }

	  public double getBalance() {
	    return balance;
	  }
	}

	class InsufficientFundsException extends RuntimeException {
	  public InsufficientFundsException(String message) {
	    super(message);
	  }
	}

	public class EncapsulationMain 
	{

	  public static void main(String[] args) 
	  {

	    BankAccount account = new BankAccount("12345678", 100.00);

	    System.out.println("Account Number: " + account.getAccountNumber());

	    account.deposit(50.00);
	    System.out.println("Balance after deposit: $" + account.getBalance());

	    try
	    {
	      account.withdraw(-20.00);
	    } catch (IllegalArgumentException e) {
	      System.out.println("Error: " + e.getMessage());
	    }

	    account.withdraw(30.00);
	    System.out.println("Balance after withdrawal: $" + account.getBalance());

	    try 
	    {
	      account.withdraw(150.00);
	    } catch (InsufficientFundsException e) {
	      System.out.println("Error: " + e.getMessage());
	    }
	  }
	}
