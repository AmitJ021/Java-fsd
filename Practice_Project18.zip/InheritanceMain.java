package Practice;

 class Vehicle {

	  private String brand;
	  private int wheels;

	  public Vehicle(String brand, int wheels) {
	    this.brand = brand;
	    this.wheels = wheels;
	  }

	  public String getBrand() {
	    return brand;
	  }

	  public int getWheels() {
	    return wheels;
	  }

	  public void start() {
	    System.out.println("Vehicle starting...");
	  }
	}

	 class Car extends Vehicle {

	  private int doors;

	  public Car(String brand, int wheels, int doors) {
	    super(brand, wheels); 
	    this.doors = doors;
	  }

	  public int getDoors() {
	    return doors;
	  }

	  @Override
	  public void start() {
	    super.start(); 
	    System.out.println("Car engine starting...");  
	  }
	}

	public class InheritanceMain {

	  public static void main(String[] args) {

	    Vehicle vehicle = new Vehicle("Generic Brand", 4);

	    System.out.println("Vehicle Brand: " + vehicle.getBrand());
	    System.out.println("Vehicle Wheels: " + vehicle.getWheels());
	    vehicle.start(); 

	    Car car = new Car("Toyota", 4, 4);

	    System.out.println("\nCar Brand: " + car.getBrand()); 
	    System.out.println("Car Wheels: " + car.getWheels()); 

	    System.out.println("Car Doors: " + car.getDoors());

	    car.start(); 
	  }
	}
