package Practice;

interface Printable 
{  
	  default void print() 
	  {  
	    System.out.println("Default Printable");
	  }
	}

	interface Displayable 
	{  
	  default void print() 
	  { 
	    System.out.println("Default Displayable");
	  }
	}

	public class DiamondMain implements Printable, Displayable 
	{  

	  @Override
	  public void print() 
	  {  
	    Printable.super.print();
	    Displayable.super.print();
	  }

	  public static void main(String[] args) 
	  {
	    DiamondMain obj = new DiamondMain();
	    obj.print();
	  }
	}
