package Practice;

public class OrderStatistics 
{

	  public static int findKthSmallest(int[] data, int k) 
	  {
	    if (k <= 0 || k > data.length) {
	      throw new IllegalArgumentException("Invalid value for k");
	    }

	    shuffleArray(data);

	    return selectKth(data, 0, data.length - 1, k);
	  }

	  private static void shuffleArray(int[] arr) 
	  {
	    for (int i = arr.length - 1; i > 0; i--) 
	    {
	      int j = (int) (Math.random() * (i + 1));
	      int temp = arr[i];
	      arr[i] = arr[j];
	      arr[j] = temp;
	    }
	  }

	  private static int selectKth(int[] data, int low, int high, int k) 
	  {
	    if (low == high) {
	      return data[low];
	    }

	    int pivotIndex = partition(data, low, high);

	    if (pivotIndex == k - 1) 
	    {
	      return data[pivotIndex];
	    } 
	    else if (k - 1 < pivotIndex) 
	    {
	      return selectKth(data, low, pivotIndex - 1, k);
	    } 
	    else 
	    {
	      // Search in the right sub-array (larger elements)
	      return selectKth(data, pivotIndex + 1, high, k);
	    }
	  }

	  private static int partition(int[] data, int low, int high) 
	  {
	    int pivot = data[high];
	    int i = low - 1;
	    for (int j = low; j < high; j++) 
	    {
	      if (data[j] <= pivot) {
	        i++;
	        int temp = data[i];
	        data[i] = data[j];
	        data[j] = temp;
	      }
	    }
	    int temp = data[i + 1];
	    data[i + 1] = data[high];
	    data[high] = temp;
	    return i + 1;
	  }

	  public static void main(String[] args) 
	  {
	    int[] data = {12, 3, 5, 7, 4, 19, 26};
	    int k = 4; 

	    try 
	    {
	      int kthSmallest = findKthSmallest(data.clone(), k);
	      System.out.println("The " + k + "th smallest element is " + kthSmallest);
	    } 
	    catch (IllegalArgumentException e) 
	    {
	      System.out.println(e.getMessage());
	    }
	  }
	}

