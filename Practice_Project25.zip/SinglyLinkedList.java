package Practice;

public class SinglyLinkedList 
{

	  private Node head; 

	  private static class Node 
	  {
	    int data;
	    Node next;

	    public Node(int data) 
	    {
	      this.data = data;
	      this.next = null;
	    }
	  }

	  public static void insert(SinglyLinkedList list, int data)
	  {
	    Node new_node = new Node(data);
	    if (list.head == null) {
	      list.head = new_node;
	      return;
	    }
	    Node current = list.head;
	    while (current.next != null) 
	    {
	      current = current.next;
	    }
	    current.next = new_node;
	  }

	  public void deleteByKey(int key) 
	  {
	    Node prev = null;
	    Node curr = head;
	    while (curr != null && curr.data != key) 
	    {
	      prev = curr;
	      curr = curr.next;
	    }

	    if (curr == null) {
	      System.out.println(key + " not found");
	      return;
	    }

	    if (prev == null)
	    {
	      head = curr.next;
	    } 
	    else 
	    {
	      prev.next = curr.next;
	    }
	    System.out.println(key + " found and deleted");
	  }

	  public static void printList(SinglyLinkedList list) 
	  {
	    Node currNode = list.head;
	    System.out.print("LinkedList: ");
	    while (currNode != null) 
	    {
	      System.out.print(currNode.data + " ");
	      currNode = currNode.next;
	    }
	    System.out.println();
	  }

	  public static void main(String[] args) 
	  {
	    SinglyLinkedList list = new SinglyLinkedList();

	    insert(list, 1);
	    insert(list, 4);
	    insert(list, 5);
	    insert(list, 2);
	    insert(list, 3);
	    insert(list, 7);



	    printList(list);

	    list.deleteByKey(4);
	    printList(list);

	    list.deleteByKey(6);


	    printList(list);
	  }
	}
