package Practice;

public class DoublyLinkedList 
{

	  static class Node {
	    int data;
	    Node prev;
	    Node next;

	    Node(int data) {
	      this.data = data;
	      this.prev = null;
	      this.next = null;
	    }
	  }

	  Node head;

	  public void push(int data) 
	  {
	    Node newNode = new Node(data);
	    newNode.next = head;
	    if (head != null) 
	    {
	      head.prev = newNode;
	    }
	    head = newNode;
	  }

	  public void insertAfter(Node prevNode, int data) 
	  {
	    if (prevNode == null) 
	    {
	      System.out.println("The given previous node cannot be NULL");
	      return;
	    }

	    Node newNode = new Node(data);
	    newNode.next = prevNode.next;
	    prevNode.next = newNode;
	    newNode.prev = prevNode;
	    if (newNode.next != null) {
	      newNode.next.prev = newNode;
	    }
	  }

	  public void append(int data) 
	  {
	    Node newNode = new Node(data);
	    if (head == null) 
	    {
	      head = newNode;
	      return;
	    }

	    Node lastNode = head;
	    while (lastNode.next != null) 
	    {
	      lastNode = lastNode.next;
	    }
	    lastNode.next = newNode;
	    newNode.prev = lastNode;
	  }

	  public void printForward()
	  {
	    Node temp = head;
	    while (temp != null) 
	    {
	      System.out.print(temp.data + " ");
	      temp = temp.next;
	    }
	    System.out.println();
	  }

	  public void printBackward() 
	  {
	    Node temp = head;

	    if (temp == null) 
	    {
	      return;
	    }
	    while (temp.next != null) {
	      temp = temp.next;
	    }

	    while (temp != null) 
	    {
	      System.out.print(temp.data + " ");
	      temp = temp.prev;
	    }
	    System.out.println();
	  }

	  public static void main(String[] args) 
	  {
	    DoublyLinkedList list = new DoublyLinkedList();

	    list.push(4);

	    list.append(1);
	    list.append(7);
	    list.append(8);
	    list.append(6);

	    Node node7 = list.head.next.next; // Get a reference to the node with data 7

	    if (node7 != null) 
	    {
	      list.insertAfter(node7, 5);
	    } 
	    else
	    {
	      System.out.println("Cannot insert after node 7 as the list might be empty or node 7 doesn't exist.");
	    }

	    System.out.println("Created DLL is:");
	    System.out.println("Traversal in forward direction");

	    list.printForward(); 

	    System.out.println("Traversal in reverse direction");
	    list.printBackward(); 
	  }
	}
