package Practice;

public class Stack 
{

	  private int[] arr; 
	  private int top; 

	  public Stack(int size) 
	  {
	    arr = new int[size];
	    top = -1; 
	  }

	  public void push(int data) 
	  {
	    if (top == arr.length - 1) 
	    {
	      System.out.println("Stack Overflow! Cannot push element as stack is full.");
	      return;
	    }
	    top++;
	    arr[top] = data;
	    System.out.println(data + " pushed into stack"); 
	  }

	  public int pop() 
	  {
	    if (top == -1) 
	    {
	      System.out.println("Stack Underflow! Cannot pop element as stack is empty.");
	      return -1; 
	    }
	    int poppedElement = arr[top];
	    top--;
	    return poppedElement;
	  }

	  public boolean isEmpty()
	  {
	    return top == -1;
	  }

	  public int peek() 
	  {
	    if (top == -1) 
	    {
	      System.out.println("Stack is empty! Cannot peek.");
	      return -1;
	    }
	    return arr[top];
	  }

	  public void display() 
	  {
	    if (top == -1) 
	    {
	      System.out.println("Stack is empty!");
	      return;
	    }
	    System.out.print("Stack elements: ");
	    for (int i = top; i >= 0; i--)
	    {
	      System.out.print(arr[i] + " ");
	    }
	    System.out.println();
	  }

	  public static void main(String[] args)
	  {
	    Stack stack = new Stack(5); 

	    stack.push(10);
	    stack.push(20);
	    stack.push(30);

	    System.out.println("Popped element: " + stack.pop()); 
	    stack.display(); 

	    stack.push(40);
	    stack.push(50);

	    System.out.println("Top element: " + stack.peek()); 
	    System.out.println("Is stack empty? " + stack.isEmpty()); 

	    stack.pop();
	    stack.pop();
	    stack.pop();

	    if (stack.isEmpty()) {
	      System.out.println("Stack is empty after popping elements.");
	    }
	  }
	}
