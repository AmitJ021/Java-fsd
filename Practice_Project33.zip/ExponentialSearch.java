package Practice;

public class ExponentialSearch 
{

	  public static int search(int[] arr, int target) 
	  {
	    int n = arr.length;

	    int i = 1;
	    while (i < n && arr[i] <= target) 
	    {
	      i *= 2;
	    }

	    i = Math.min(i, n - 1);

	    return binarySearch(arr, target, i / 2, i);
	  }

	  private static int binarySearch(int[] arr, int target, int low, int high) 
	  {
	    while (low <= high) 
	    {
	      int mid = low + (high - low) / 2;

	      if (arr[mid] == target) 
	      {
	        return mid;
	      } 
	      else if (arr[mid] < target) 
	      {
	        low = mid + 1;
	      } else {
	        high = mid - 1;
	      }
	    }
	    return -1;
	  }

	  public static void main(String[] args) 
	  {
	    int[] arr = {2, 3, 4, 10, 40};
	    int target = 10;

	    int index = search(arr, target);

	    if (index != -1) 
	    {
	      System.out.println("Element " + target + " is found at index " + index);
	    } else {
	      System.out.println("Element " + target + " is not found in the array");
	    }
	  }
	}
