import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Dashboard")
public class Dashboard extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h1>Dashboard</h1>");
        
        boolean useUrlRewriting = Boolean.parseBoolean(request.getParameter("useUrlRewriting"));
        if (useUrlRewriting) {
            response.getWriter().println("<p>Session handled with URL Rewriting</p>");
        } else {
            response.getWriter().println("<p>Session handled without URL Rewriting</p>");
        }
    }
}
